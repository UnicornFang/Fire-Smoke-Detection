# undefined > 2022-02-09 3:53pm For K80 RAM
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

undefined