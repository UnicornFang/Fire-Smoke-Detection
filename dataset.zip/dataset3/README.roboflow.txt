
Fire and Smoke Dataset - v4 2022-02-09 3:53pm For K80 RAM
==============================

This dataset was exported via roboflow.ai on February 9, 2022 at 7:56 AM GMT

It includes 10979 images.
Labeled-fire-and-smoke are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Fit within)

The following augmentation was applied to create 2 versions of each source image:
* 50% probability of horizontal flip
* Random rotation of between -11 and +11 degrees
* Random shear of between -8° to +8° horizontally and -7° to +7° vertically
* Random exposure adjustment of between -5 and +5 percent
* Random Gaussian blur of between 0 and 0.25 pixels


